# Python-Project
My group and I created "Speed Typing Test" which actually tests the writing speed on selecting different modes and difficulty levels.
The 'Speed Typing Test' has 2 modes that are Practice Mode and Competition Mode.On selecting either of the mode,it will then ask you the difficulty level after which user will actually
start the typing test.
Once you are done with the test, the terminal wil display the speed and time taken by you to type. After which you can actually give yourself a try again or simply end it by giving the feedback.

